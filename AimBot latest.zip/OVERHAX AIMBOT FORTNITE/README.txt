|Title: OVERHAX-FORTNITE-AIMBOT-FREE Ver: Pre 0.4a Architecture: x64                 |

|Credits: See credits.txt                                                            |

|Our offical discord:https://discord.gg/y3VgmZM                                      |

|Website: overhax.ml                                                                 |

|____________________________________________________________________________________|

https://github.com/THEGUY3ds/OVERHAX-FORTNITE-AIMBOT/raw/master/AimBot%20latest.zip

How to fix errors:

Fix xp bot not working

Change settings to WindowedFullscreen and set display resolution to 1920x1080 16:9.

Fix aimbot not working

Change settings to borderless windowed mode.